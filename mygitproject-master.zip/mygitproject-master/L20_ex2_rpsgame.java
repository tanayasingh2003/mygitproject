import java.util.Random;
import java.util.*;

public class L20_ex2_rpsgame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner sc= new Scanner(System.in);
    Random comp=new Random();
    int cp=0;
    int pp=0;
    System.out.println("Welcome, Let's play Rock paper scissors.");
    System.out.println("Instructions: Type 1,2,3; Here:1-->Rock,2-->Paper,3-->Scissor");
    System.out.println("How many rounds are you wiling to play?");
    int n= sc.nextInt();
    for(int i=0;i<n;i++) {
    System.out.println("Enter Choice:");
    int player=sc.nextInt();
    int rand=comp.nextInt(3)+1;
    if(player==1&&rand==1) {
    	System.out.println("player selected: Rock");
    	System.out.println("Computer selected: Rock");
    	System.out.println("It's a tie!!");}
    	
    else if(player==2&&rand==2) {
    		System.out.println("player selected: paper");
    		System.out.println("computer selected:paper");
    		System.out.println("It,s a tie");
    		cp+=1;pp+=1;}
            
    	else if(player==3&&rand==3) {
    		System.out.println("player selected: Scissors");
    		System.out.println("computer selected: Scissors");
    		System.out.println("It,s a tie");
    		cp+=1;pp+=1;
    	}
    	else if(player==1&&rand==2) {
    		System.out.println("player selected: Rock");
    		System.out.println("computer selected: paper");
    		System.out.println("computer wins!");cp+=1;
    }
    	else if(player==1&&rand==3) {
    		System.out.println("player selected:Rock");
    		System.out.println("computer selected: Scissors");
    		System.out.println("Congratulations! You won this match!");pp+=1;}
    	else if(player==2&&rand==1) {
    		System.out.println("player selected: paper");
    		System.out.println("computer selected: Rock");
    		System.out.println("Congratulations ,You won this match!");pp+=1;
    	}
    	else if(player==2&&rand==3) {
    		System.out.println("player selected:paper");
    		System.out.println("computer selected: Scissors");
    		System.out.println("Computer wins!");cp+=1;}
    	else if(player==3&&rand==1) {
    		System.out.println("player selected: Scissors");
    		System.out.println("computer selected:Rock");
    		System.out.println("Computer wins!");}
    	else if(player==3&&rand==2) {
    		System.out.println("player selected: Scissors");
    		System.out.println("computer selected: paper");
    		System.out.println("Congratulations ,You won this match!");
	}
    	else {
    		System.out.println("Invalid input");
    	}
    if(cp>pp) {
    	System.out.println("Computer points:"+cp);
    	System.out.println("Your points:"+pp);
    	System.out.println("You lose!better luck next Time");
    }
    else if(pp>cp) {
    	System.out.println("Computer points:"+cp);
    	System.out.println("Your points:"+pp);
    	System.out.println("Congratulations!You won the match");
    }
    else if(cp==pp&&cp!=0&&pp!=0) {
    	System.out.println("Computer points:"+cp);
    	System.out.println("Your points:"+pp);
    	System.out.println("It's a tie");
    }
    else if(cp==pp&&cp==0&&pp==0) {
    	System.out.println("Trying typing numbers between 1,2,3, 1 - Rock, 2-Paper ,3-Scissor");
    }
    	
    
    
    
    	
    }

}}
